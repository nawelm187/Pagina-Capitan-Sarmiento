# Memoria de Capitán Sarmiento

Archivo web de fotografías y documentos históricos de Capitán Sarmiento (provincia de Buenos Aires). Es un sitio estático: un `index.html` y la carpeta `img/`. No necesita instalación ni servidor.

## Publicar en GitHub Pages
1. Subí el contenido de esta carpeta a un repositorio.
2. En el repositorio: Settings, Pages, "Deploy from a branch", rama `main`, carpeta `/ (root)`.
3. Esperá unos minutos y abrí la dirección que muestra GitHub.

## Probar en tu computadora
Abrí una terminal en esta carpeta y ejecutá `python3 -m http.server`. Después entrá a `http://localhost:8000`.

## Agregar o editar contenido
Todo el contenido está en la parte de `<script>` de `index.html`:
- `P`: fotografías. `DOC`: documentos. `H`: hitos de la línea de tiempo.
- Fotos nuevas: copiá la imagen a `img/` y agregala al objeto `IMG` (ruta, ancho y alto en píxeles) y a `P`.
- Completá `date` y `dc` (cómo se sabe la fecha) solo cuando estén documentadas. Un campo ausente se muestra como "Fecha desconocida".

## Antes y ahora
No es una página aparte: está dentro de cada fotografía. Cuando una foto antigua tiene su foto actual, al tocarla se abre la vista ampliada con una barra: hacia la derecha se ve la actual y hacia la izquierda, la antigua.
Para activarlo, copiá la foto actual a `img/` y agregá este campo a la foto en `P`:
`now:{src:"img/ahora-estacion.jpg",alt:"Descripción de la foto actual",date:"2026"}`
La foto actual se recorta para ocupar el mismo encuadre que la antigua, así que conviene tomarla desde el mismo punto y con una proporción parecida. Las fotos sin `now` se amplían sin barra.

## Originales
`originales/` guarda las imágenes tal como llegaron. `img/` tiene las copias de consulta (hasta 1600 px, sin metadatos). No edites los originales.

## Pendiente
- Fechas y ubicación exacta de cada pieza (las fichas indican qué falta confirmar).
- Fotos actuales para el comparador.
- No se midió accesibilidad ni rendimiento con herramientas; probalo en un celular antes de difundirlo.
